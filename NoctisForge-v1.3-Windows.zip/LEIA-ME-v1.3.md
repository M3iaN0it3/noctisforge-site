# NoctisForge v1.3 — Correção da exportação e FTB Quests

**Criado Por MeiaNoite.** Atualização sobre a base v1.2, preservando a estrutura do aplicativo e dos modpacks salvos.

## Erro da API corrigido
A interface envia a exportação combinada como `multipart/form-data`, já que pode haver um ZIP de tradução. Na v1.2, o filtro de segurança exigia `application/json` também nesta rota e impedia qualquer exportação.

- `/api/export-combined` agora aceita **somente** `multipart/form-data` com parâmetro `boundary` válido.
- Rotas JSON continuam exigindo `application/json`; não houve liberação global.
- A exportação sem quest ou tradução gera normalmente `.mrpack` após verificar as versões e dependências.
- Erros de exportação aparecem dentro do modal, não escondidos atrás da janela.

## FTB Quests ausente
Ao marcar `Incluir FTB Quests diretamente no pacote` sem ter FTB Quests na lista:

1. Aparece um alerta **à frente** da janela de exportação.
2. `Adicionar FTB Quests` tenta encontrar o projeto oficial exato no Modrinth, para a versão e loader do pack. Se achar, a inclusão passa por `/api/check-add` e pelas verificações de dependências/conflitos.
3. Se não achar, mostra **Abrir FTB Quests no CurseForge** e informa que o mod e as dependências devem ser instalados manualmente. Não confunde addons com o mod principal.
4. Só após clicar em **Vou instalar manualmente e quero gerar as missões** será possível exportar quests com o FTB Quests ausente da lista. O pacote contém `overrides/LEIA-ME-FTB-QUESTS-OBRIGATORIO.txt` e as missões, **mas NÃO contém o JAR do FTB Quests**.
5. Para exportar sem missões, desmarque `FTB Quests`. Não é necessária a confirmação nem o mod.

**Atenção:** atualmente o FTB Quests oficial é distribuído via CurseForge e pode não existir no catálogo do Modrinth. Não foi feita integração para baixar e redistribuir JARs do CurseForge automaticamente. O botão tenta a busca segura e encaminha ao site oficial quando necessário. Instalar manualmente FTB Quests (e dependências) no launcher é responsabilidade do usuário. Mods e quests gerados ainda devem ser testados no Minecraft antes da publicação.

## Arquivos de distribuição
- `NoctisForge_v1.3.exe`: executável de interface gráfica Windows 64-bit; Python não é necessário.
- `NoctisForge.ico` / `NoctisForge.png`: identidade visual preservada.
- Código-fonte Go + HTML/CSS/JS e testes: disponível em arquivo separado.

## Testes
- Testes Go de regressão e dos cenários de exportação multimídia: passaram no ambiente de desenvolvimento.
- Teste da interface no Chromium com API simulada: passou (aviso, retorno, instalação manual, exportação sem extras, exibição de erros).
- A integração real com CurseForge, FTB Quests no Minecraft e a execução final do binário em Windows ainda dependem de teste externo.
- O executável não tem assinatura digital; o SmartScreen pode exibir aviso de fabricante desconhecido.
