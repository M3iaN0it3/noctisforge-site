# NoctisForge v1.3 — Criado Por MeiaNoite

Versão de correção da exportação e dos avisos do FTB Quests. Leia `LEIA-ME-v1.3.md` para detalhes.

No Windows 10/11 x64, extraia o pacote, feche a instância antiga e abra `NoctisForge_v1.3.exe`.
Sem instalação de Python. Sem assinatura digital. Seus projetos existentes são preservados.
